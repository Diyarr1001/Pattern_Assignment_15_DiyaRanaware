package com.assignment;

import java.util.Scanner;

public class Pattern12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int h = 5; 
        for (int i = 0; i < h; i++) {
            for (int j = h - i - 1; j > 0; j--) {
                System.out.print(" ");
            }

            for (int j = 0; j < (2 * i + 1); j++) {
                System.out.print(" * ");
            }

            System.out.println(); 
        }


	}

}
