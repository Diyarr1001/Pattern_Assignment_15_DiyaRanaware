package com.assignment;

import java.util.Scanner;

public class Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner sc= new Scanner(System.in);
		
		System.out.println("ENTER VALUE: ");
		int n=sc.nextInt();
		
		char ch ='A';
		
		for(int i=0;i<=n;i++) {
			for(int j=0;j<=n;j++){
				System.out.print((char)(ch+i+j)+" ");
				
			}
			System.out.println();
		}



	}

}
