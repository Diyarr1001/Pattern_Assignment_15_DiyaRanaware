package com.assignment;

import java.util.Scanner;

public class Pattern13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int rows = 4; 
	        int number = 1; 

	        for (int i = 1; i <= rows; i++) {
	            for (int j = rows - i; j > 0; j--) {
	                System.out.print(" ");
	            }

	            for (int j = 0; j < i; j++) {
	                System.out.print(number++);
	            }

	            System.out.println(); 
	        }
	}

}
